// Import the functions you need from the SDKs you need

import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";

// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional

const firebaseConfig = {
  apiKey: "AIzaSyC537ssx5UGEeMS2EdU0ypCnhW090E0w60",
  authDomain: "todo-1af17.firebaseapp.com",
  projectId: "todo-1af17",
  storageBucket: "todo-1af17.appspot.com",
  messagingSenderId: "554187162447",
  appId: "1:554187162447:web:5070a4443500e685ab3b3a",
  measurementId: "G-YRM3K94WT0"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);