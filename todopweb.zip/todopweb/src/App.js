import './App.css';
import Todo from './components/Todo';

function App() {
  return (
    <div className="App">
      <Todo> Todo </Todo>
    </div>
  );
}

export default App;
