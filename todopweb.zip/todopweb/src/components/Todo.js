function Todo() {
  return (
    <div>
      <h1>TODO</h1>
    </div>
  );
}

export default Todo;